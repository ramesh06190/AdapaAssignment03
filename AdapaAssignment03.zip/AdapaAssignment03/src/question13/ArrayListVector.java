package question13;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
/**
 * 
 * @author S555173
 *
 */
public class ArrayListVector {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating an ArrayList
	        ArrayList<String> al = new ArrayList<String>();
	        // adding object to arraylist
	        al.add("ColdenHall");
	        al.add("WellsHall");
	        al.add("ValkCentre");
	        al.add("GS");
	        // traversing elements using Iterator'
	        System.out.println("ArrayList is :");
	        Iterator it = al.iterator();
	        while (it.hasNext())
	            System.out.println(it.next());
	        // creating Vector
	        Vector<String> v = new Vector<String>();
	        v.addElement("Today");
	        v.addElement("Will be");
	        v.addElement("a Good Day");
	        // traversing elements using Enumeration
	        System.out.println("\nVector is:");
	        Enumeration e = v.elements();
	        while (e.hasMoreElements())
	            System.out.println(e.nextElement());
	    }
	}
