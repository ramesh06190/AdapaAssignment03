package question08;

import java.util.Scanner;
/**
 * 
 * @author S555173
 *
 */
public class TryWithoutCatchExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();
            System.out.println("You entered: " + number);
        } finally {
            scanner.close();
            System.out.println("Finally block executed");
        }
    }
}
