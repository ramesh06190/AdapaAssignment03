package question03;
/**
 * 
 * @author S555173
 *
 */
public class Fruit {
    public Fruit getFruit() {
        return new Fruit();
    }
}

class Apple extends Fruit {
    @Override
    public Apple getFruit() {
        return new Apple();
    }
}
