package question01;

import java.util.EmptyStackException;
/**
 * 
 * @author S555173 Pydi Venkata Satya Ramesh Adapa
 *
 * @param <T>
 */
public class Stack<T> {
    private T[] stackArray;
    private int top;
    private int size;
 
    @SuppressWarnings("unchecked")
	public Stack(int size) {
        this.size = size;
        this.stackArray = (T[]) new Object[size];
        this.top = -1;
    }
 
    public void push(T element) {
        if (isFull()) {
            throw new StackOverflowError("Stack is full");
        }
        stackArray[++top] = element;
    }
 
    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stackArray[top--];
    }
 
    public boolean isFull() {
        return top == size - 1;
    }
 
    public boolean isEmpty() {
        return top == -1;
    }
}

