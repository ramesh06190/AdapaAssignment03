package question01;
public class StackDriver {
    public static void main(String[] args) {
        // Create a new stack that can hold integers
        Stack<Integer> intStack = new Stack<>(5);
        intStack.push(619);
        intStack.push(781);
        intStack.push(334);
        intStack.push(1511);
        intStack.push(1001);

        // Pop elements from the stack
        while (!intStack.isEmpty()) {
            System.out.println(intStack.pop());
        }

        // Create a new stack that can hold strings
        Stack<String> stringStack = new Stack<>(3);
        stringStack.push("Hello");
        stringStack.push("World");
        stringStack.push("!");

        // Pop elements from the stack
        while (!stringStack.isEmpty()) {
            System.out.println(stringStack.pop());
        }
    }
}
