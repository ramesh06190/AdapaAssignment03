package question12;
/**
 * @author S555173
 *
 */
public class FinallyKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try 
		{	System.out.println("Inside the try block");
			int a = 87123/0;
			System.out.println(a);
		}
		catch(ArithmeticException e) {
			System.out.println("Exception handled");
			System.out.println(e);
		}
		finally {
			System.out.println("Finally block executed");
		}
		System.out.println("end of try catch and finally");
	}

}
