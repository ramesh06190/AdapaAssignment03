package question12;
/**
 * 
 * @author S555173
 *
 */
public class FinalKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 619;
		final int b = 178;
		a++;
		//b++;// we cannot modify the final keyword so we get complie time error

	}

}
