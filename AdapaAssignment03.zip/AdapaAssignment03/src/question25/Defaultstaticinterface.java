package question25;

public interface Defaultstaticinterface {
	 default void show() {
	      System.out.println("Hello world");
	   }
	   static void display() {
	      System.out.println("in the interface");
	   }
	}

