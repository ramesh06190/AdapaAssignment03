package question25;
/**
 * 
 * @author S555173
 *
 */
public class Functionallambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// lambda expression to create the object
        new Thread(() -> {
            System.out.println("New thread created");
        }).start();
   	 }
	}

