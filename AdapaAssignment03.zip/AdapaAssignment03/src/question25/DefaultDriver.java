package question25;
/**
 * 
 * @author S555173
 *
 */
public class DefaultDriver implements Defaultstaticinterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Defaultstaticinterface.display();
		DefaultDriver defaultStaticExampleClass = new DefaultDriver();
	     
	      // Call default method on Class
	      defaultStaticExampleClass.show();
	   }


	}
