package question25;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
/**
 * 
 * @author S555173
 *
 */
public class ForEachExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> data = new ArrayList<>();
        data.add("Vizag");
        data.add("Hyd");
        data.add("Delhi");
        data.add("Shimla");
        data.forEach(new Consumer<String>() {
            @Override
            public void accept(String t)
            {
                System.out.println(t);
            }
        });
	}
}
