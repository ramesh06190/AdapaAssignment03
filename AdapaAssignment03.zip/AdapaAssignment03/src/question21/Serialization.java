package question21;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
/**
 * 
 * @author S555173
 *
 */
public class Serialization implements Serializable {
		 int sid;  
		 String name;  
		 public Serialization(int id, String name) 
		 {  
		  this.sid = id;  
		  this.name = name;  
		 }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{    
			  //Creating the object    
			Serialization s1 =new Serialization(151,"Raju");    
			  //Creating stream and writing the object    
			  FileOutputStream fout=new FileOutputStream("f.txt");    
			  ObjectOutputStream out=new ObjectOutputStream(fout);    
			  out.writeObject(s1);    
			  out.flush();    
			  //closing the stream    
			  out.close();    
			  System.out.println("success");    
			  }catch(Exception e){System.out.println(e);}    
			 }    
	}

