package question26;
/**
 * 
 * @author S555173
 *
 */
public class pureSingleton {

	

private static volatile pureSingleton sSoleInstance = new pureSingleton();

		    //private constructor.
		    private pureSingleton(){}

		    public static pureSingleton getInstance() {
		        return sSoleInstance;
		    }
		    public static void main(String[] args) {
		    	// TODO Auto-generated method stub
		    	pureSingleton instance1 = pureSingleton.getInstance();

		        //Instance 2
		    	pureSingleton instance2 = pureSingleton.getInstance();

		        //now lets check the hash key.
		        System.out.println("Instance 1 hash:" + instance1.hashCode());
		        System.out.println("Instance 2 hash:" + instance2.hashCode());  
		   }
	}

