package question02;

public class Animal {
    public void sound() {
        System.out.println("The animal makes a sound.");
    }
}


class Cat extends Animal {
    // Override with protected access level
	//Error as we cannot reduce the visibilty from public to default
   /* void sound() {
        System.out.println("The cat meows.");
    }*/
   
}
class Dog extends Animal{
	  // Override with default access level
  //@Override
	/*void sound() {
      System.out.println("The dog barks.");
  }*/
  
  // Override with protected access level
  //Error as we cannot reduce the visibilty from public to protected 
  /*protected void sound() {
      System.out.println("The dog barks.");
  }*/
}

