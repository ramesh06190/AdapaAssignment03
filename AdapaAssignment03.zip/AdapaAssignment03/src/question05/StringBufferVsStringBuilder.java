package question05;
/**
 * 
 * @author S555173
 *
 */
public class StringBufferVsStringBuilder {
    public static void main(String[] args) {
        StringBuffer stringBuffer = new StringBuffer();
        StringBuilder stringBuilder = new StringBuilder();

        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 200000; i++) {
            stringBuffer.append("a");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuffer: " + (endTime - startTime) + "ms");

        startTime = System.currentTimeMillis();
        for (int i = 0; i < 200000; i++) {
            stringBuilder.append("a");
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuilder: " + (endTime - startTime) + "ms");
    }
}

