package question07;
/**
 * 
 * @author S555173
 *
 */
public class Dog {
    private final String name;

    public Dog(String name) {
        this.name = name;
    }

    // Error: Cannot declare a constructor as final
    // public final Dog() { ... }
}

