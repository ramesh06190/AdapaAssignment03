package question17;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
/**
 * 
 * @author S555173
 *
 */
public class Failsafe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<Integer>(new Integer[] { 619,456,723,567 });
		Iterator itr = list.iterator();
		while (itr.hasNext()) {
        Integer no = (Integer)itr.next();
        System.out.println(no);
        if (no == 345)
            // This will not print,
            // hence it has created separate copy
            list.add(365);
		}
	}
}

