package question06;
/**
 * 
 * @author S555173
 *
 */
public class StringVsStringBuffer {
    public static void main(String[] args) {
        String string = "hello";
        StringBuffer stringBuffer = new StringBuffer("hello");

        // Modify the string
        string += " world";
        stringBuffer.append(" world");

        System.out.println("String: " + string); // "hello world"
        System.out.println("StringBuffer: " + stringBuffer.toString()); // "hello world"
    }
}

