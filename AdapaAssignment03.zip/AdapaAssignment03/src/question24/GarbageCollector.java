package question24;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author S555173
 *
 */
public class GarbageCollector {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runtime runtimeObj = Runtime.getRuntime();
        for (int i=0; i<= 500000; i++) {
            List<Integer> list = new ArrayList<>();
            list.add(9);
            list.add(2);
            list.add(6);
        }
        System.out.println("Memory before  : " + runtimeObj.freeMemory());
        System.gc();
        System.out.println("Memory after : " + runtimeObj.freeMemory());
    }
	}

