package question22;
/**
 * 
 * @author S555173
 *
 */
public class Immutable {  
	private String str;  
	Immutable(String s) {  
		this.str = s;  
	}  
	public String getName() {  
		return str;  
	}  
	public void setName(String coursename) {  
		this.str = coursename;  
	}  
	public static void main(String[] args) {  
		Immutable object = new Immutable("Namaste");  
		System.out.println(object.getName());   
		object.setName("Sasriakal Aadaab");  
		System.out.println(object.getName());  
	}  
}  

