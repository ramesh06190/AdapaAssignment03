package question15;


import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashTableMap{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//HashTable
        Hashtable<Integer,String> ht=new Hashtable<Integer,String>();
        ht.put(1,"Pydi");
        ht.put(2,"Venkata");
        ht.put(3,"Satya");
        ht.put(4,"Ramesh");
        System.out.println("-------------Hash table--------------");
        for (Map.Entry m:ht.entrySet()) {
            System.out.println(m.getKey()+" "+m.getValue());
        }
 
        //HashMap
        HashMap<Integer,String> hm=new HashMap<Integer,String>();
        hm.put(2,"Venkata");
        hm.put(4,"Ramesh"); 
        hm.put(1,"Pydi");
        hm.put(3,"Satya");
        System.out.println("-----------Hash map-----------");
        for (Map.Entry m:hm.entrySet()) {
            System.out.println(m.getKey()+" "+m.getValue());
        }
    }
}
