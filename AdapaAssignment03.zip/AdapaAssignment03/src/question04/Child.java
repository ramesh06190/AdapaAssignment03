package question04;
/**
 * 
 * @author S555173
 *
 */
public class Child extends Parent {
    private static void privateMethod() {
        System.out.println("Child's private method");
    }

    public static void staticMethod() {
        System.out.println("Child's static method");
    }
}
