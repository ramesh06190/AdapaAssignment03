package question04;
/**
 * 
 * @author S555173
 *
 */
public class Driver {

	    public static void main(String[] args) {
	        Parent parent = new Child();
	        Child child = new Child();

	        parent.staticMethod(); // Output: "Parent's static method"
	        child.staticMethod(); // Output: "Child's static method"

	        // The following lines will result in compilation errors:
	        // parent.privateMethod(); // Compilation error: privateMethod() has private access in Parent
	        // child.privateMethod(); // Compilation error: privateMethod() has private access in Child
	    }
}
