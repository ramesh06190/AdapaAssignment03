package question04;
/**
 * 
 * @author S555173
 *
 */
public class Parent {
    private static void privateMethod() {
        System.out.println("Parent's private method");
    }

    public static void staticMethod() {
        System.out.println("Parent's static method");
    }
}
