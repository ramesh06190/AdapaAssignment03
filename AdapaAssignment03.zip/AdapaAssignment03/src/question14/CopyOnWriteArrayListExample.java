package question14;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
/**
 * @author S555173
 *
 */
public class CopyOnWriteArrayListExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating a thread-safe Arraylist.
        CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<String>();
        // Adding elements to synchronized ArrayList
        list.add("Mobile Computing");
        list.add("Advanced Data Base");
        list.add("Frameworks");
        System.out.println("Elements of synchronized ArrayList :");
        // Iterating on the synchronized ArrayList using iterator.
        Iterator<String> it = list.iterator();
        while (it.hasNext())
            System.out.println(it.next());
    }
}
