package question14;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
/**
 * @author S555173
 *
 */
public class ArrayListSynchr {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = Collections.synchronizedList(new ArrayList<String>()); 
		list.add("Tomorrow");
		list.add("will also be a");
		list.add("Good Day"); 
		synchronized(list)
		{// must be in synchronized block
		    Iterator itr = list.iterator();
		    while (itr.hasNext())
		    System.out.println(itr.next());
		        }
		    }
	}
