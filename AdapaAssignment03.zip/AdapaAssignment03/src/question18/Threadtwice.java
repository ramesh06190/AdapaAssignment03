package question18;

/**
 * 
 * @author S555173
 *
 */
public class Threadtwice extends Thread{  
	 public void run(){  
		   System.out.println("running...");  
		 } 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threadtwice thread1=new Threadtwice();  
		  thread1.start();  
		  thread1.start();  
		 }  
}

