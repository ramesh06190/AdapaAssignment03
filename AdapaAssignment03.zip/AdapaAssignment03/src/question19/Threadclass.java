package question19;
/**
 * 
 * @author S555173
 *
 */
public class Threadclass extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threadclass t1=new Threadclass();  
		t1.start();  
		 }  
		public void run(){  
			System.out.println("thread is running...");  
			}  	 
	}

