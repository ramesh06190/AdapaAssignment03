package question19;
/**
 * 
 * @author S555173
 *
 */
public class Threadrunnable implements Runnable {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threadrunnable m1=new Threadrunnable();  
		Thread t1 =new Thread(m1);   // Using the constructor Thread(Runnable r)  
		t1.start(); 
	}
	public void run(){  
		System.out.println("thread is running...");  
		}  
}

